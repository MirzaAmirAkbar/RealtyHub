package com.realtyhub;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class AddPropertiesPage {
    private Stage stage;
    private String loggedInUsername;

    public AddPropertiesPage(Stage stage, String loggedInUsername) {
        this.stage = stage;
        this.loggedInUsername = loggedInUsername;
    }

    public void showAddPropertiesPage() {
        // Create heading
        Label headingLabel = new Label("Add New Property");
        headingLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #007acc;");

        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);

        // Property Type input
        Label propertyTypeLabel = new Label("Property Type:");
        TextField propertyTypeField = new TextField();
        propertyTypeField.setPromptText("e.g., Apartment, House");

        // Property Address input
        Label propertyAddressLabel = new Label("Property Address:");
        TextField propertyAddressField = new TextField();
        propertyAddressField.setPromptText("e.g., 123 Street Name, City");

        // Dropdown for Rent or Sale
        Label rentOrSaleLabel = new Label("Transaction Type:");
        ComboBox<String> rentOrSaleDropdown = new ComboBox<>();
        rentOrSaleDropdown.getItems().addAll("For Rent", "For Sale");
        rentOrSaleDropdown.setPromptText("Select Transaction Type");

        // Price input
        Label priceLabel = new Label("Price:");
        TextField priceField = new TextField();
        priceField.setPromptText("Enter price in USD");

        // Add Button
        Button addButton = new Button("Add Property");
        addButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");

        addButton.setOnAction(event -> {
            String propertyType = propertyTypeField.getText();
            String propertyAddress = propertyAddressField.getText();
            String rentOrSale = rentOrSaleDropdown.getValue();
            String priceText = priceField.getText();

            // Validation
            if (propertyType.isEmpty() || propertyAddress.isEmpty() || rentOrSale == null || priceText.isEmpty()) {
                showAlert("Error", "All fields must be filled out.", Alert.AlertType.ERROR);
                return;
            }

            int price;
            try {
                price = Integer.parseInt(priceText);
                if (price < 0) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                showAlert("Error", "Price must be a positive integer.", Alert.AlertType.ERROR);
                return;
            }

            // Save to database
            PropertyDAO propertyDAO = new PropertyDAO();
            if (propertyDAO.addPropertyToDatabase(loggedInUsername, propertyType, propertyAddress, rentOrSale, price)) {
                showAlert("Success", "Property added successfully!", Alert.AlertType.INFORMATION);
                new ManagePropertiesPage(stage, loggedInUsername).showManagePropertiesPage(); // Return to manage page
            }
            else {
            	showAlert("Error", "Failed to add property to the database.", Alert.AlertType.ERROR);
            }
        });

        // Cancel Button
        Button cancelButton = new Button("Cancel");
        cancelButton.setStyle("-fx-background-color: #F44336; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");
        cancelButton.setOnAction(event -> new ManagePropertiesPage(stage, loggedInUsername).showManagePropertiesPage());

        HBox buttonBox = new HBox(20, addButton, cancelButton);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));

        // Layout
        GridPane formGrid = new GridPane();
        formGrid.setVgap(10);
        formGrid.setHgap(10);
        formGrid.setPadding(new Insets(20));

        formGrid.add(propertyTypeLabel, 0, 0);
        formGrid.add(propertyTypeField, 1, 0);
        formGrid.add(propertyAddressLabel, 0, 1);
        formGrid.add(propertyAddressField, 1, 1);
        formGrid.add(rentOrSaleLabel, 0, 2);
        formGrid.add(rentOrSaleDropdown, 1, 2);
        formGrid.add(priceLabel, 0, 3);
        formGrid.add(priceField, 1, 3);

        VBox root = new VBox(20, headingPane, formGrid, buttonBox);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #87CEEB; -fx-border-radius: 10px; -fx-border-color: #007acc; -fx-border-width: 2px;");

        Scene addPropertyScene = new Scene(root, 600, 400);
        stage.setScene(addPropertyScene);
        stage.setTitle("Add Property");
        stage.show();
    }

    private void showAlert(String title, String message, Alert.AlertType alertType) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
