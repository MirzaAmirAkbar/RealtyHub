package com.realtyhub;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class ApprovePropertiesPage {

    private Stage stage;
    private String loggedInUsername;
    private List<CheckBox> checkBoxes = new ArrayList<>();
    private List<Integer> selectedPropertyIds = new ArrayList<>();

    public ApprovePropertiesPage(Stage stage, String loggedInUsername) {
        this.stage = stage;
        this.loggedInUsername = loggedInUsername;
    }

    public void showApprovePropertiesPage() {
        // Fetch unverified properties
        PropertyDAO propertyDAO = new PropertyDAO();
        List<Property> unverifiedProperties = propertyDAO.fetchUnverifiedProperties();

        // Create VBox for property details
        VBox propertiesVBox = new VBox(15);
        propertiesVBox.setPadding(new Insets(20));
        propertiesVBox.getStyleClass().add("vbox");

        // Add property details
        for (Property property : unverifiedProperties) {
            Label propertyDetailsLabel = new Label(
                    "Owner: " + property.getPropertyOwner() + "\n" +
                    "Type: " + property.getPropertyType() + "\n" +
                    "Address: " + property.getPropertyAddress() + "\n" +
                    "Rent/Sale: " + property.getRentOrSale() + "\n" +
                    "Price: $" + property.getPrice());
            propertyDetailsLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #333;");

            CheckBox propertyCheckBox = new CheckBox("Select");
            propertyCheckBox.setOnAction(event -> {
                if (propertyCheckBox.isSelected()) {
                    selectedPropertyIds.add(property.getId());
                } else {
                    selectedPropertyIds.remove(Integer.valueOf(property.getId()));
                }
            });

            HBox propertyHBox = new HBox(20, propertyDetailsLabel, propertyCheckBox);
            propertyHBox.setAlignment(Pos.CENTER_LEFT);
            propertiesVBox.getChildren().add(propertyHBox);
        }

        // Create Approve and Back buttons
        Button approveButton = new Button("Approve");
        approveButton.getStyleClass().add("button");
        approveButton.setOnAction(event -> {
            int validation = propertyDAO.approveProperties(selectedPropertyIds);
            switch (validation) {
                case -1:
                    showAlert(Alert.AlertType.WARNING, "No Properties Selected", "Please select properties to approve.");
                    break;
                case 0:
                    showAlert(Alert.AlertType.INFORMATION, "Properties Approved", "All selected properties have been approved.");
                    stage.close();
                    new HomePage(stage, loggedInUsername).showHomePage();
                    break;
                case 1:
                    showAlert(Alert.AlertType.ERROR, "Error", "Error approving properties.");
                    break;
            }
        });

        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button");
        backButton.setOnAction(event -> {
            new HomePage(stage, loggedInUsername).showHomePage();
        });

        // Add buttons in a layout
        HBox buttonsHBox = new HBox(20, backButton, approveButton);
        buttonsHBox.setAlignment(Pos.CENTER);
        buttonsHBox.setPadding(new Insets(20));

        // Create main layout
        BorderPane root = new BorderPane();
        root.setCenter(propertiesVBox);
        root.setBottom(buttonsHBox);
        BorderPane.setMargin(buttonsHBox, new Insets(10));

        // Scene setup
        Scene scene = new Scene(root, 800, 600);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        stage.setScene(scene);
        stage.setTitle("Approve Properties");
        stage.show();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
