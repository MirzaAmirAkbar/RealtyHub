package com.realtyhub;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class CardPaymentPage {
    private Stage stage;
    private String loggedInUsername; // Buyer
    private Property selectedProperty; // Selected property details

    public CardPaymentPage(Stage stage, String loggedInUsername, Property selectedProperty) {
        this.stage = stage;
        this.loggedInUsername = loggedInUsername;
        this.selectedProperty = selectedProperty;
    }

    public void showCardPaymentPage() {
        // Heading label with styling
        Label headingLabel = new Label("Card Payment");
        headingLabel.getStyleClass().add("label-title"); // Applying the label-title style from style.css

        // GridPane form for input fields
        GridPane formPane = new GridPane();
        formPane.setPadding(new Insets(20));
        formPane.setHgap(10);
        formPane.setVgap(10);

        // Labels and fields for card details
        Label nameLabel = new Label("Cardholder Name:");
        TextField nameField = new TextField();
        nameField.getStyleClass().add("text-field"); // Applying text-field style
        nameField.setPromptText("Enter Cardholder Name");

        Label cardNumberLabel = new Label("Card Number:");
        TextField cardNumberField = new TextField();
        cardNumberField.getStyleClass().add("text-field"); // Applying text-field style
        cardNumberField.setPromptText("Enter 16-digit Card Number");

        Label expiryLabel = new Label("Expiry Date (MM/YY):");
        TextField expiryField = new TextField();
        expiryField.getStyleClass().add("text-field"); // Applying text-field style
        expiryField.setPromptText("MM/YY");

        Label cvvLabel = new Label("CVV:");
        PasswordField cvvField = new PasswordField();
        cvvField.getStyleClass().add("text-field"); // Applying text-field style
        cvvField.setPromptText("Enter CVV");

        // Add fields to form
        formPane.add(nameLabel, 0, 0);
        formPane.add(nameField, 1, 0);
        formPane.add(cardNumberLabel, 0, 1);
        formPane.add(cardNumberField, 1, 1);
        formPane.add(expiryLabel, 0, 2);
        formPane.add(expiryField, 1, 2);
        formPane.add(cvvLabel, 0, 3);
        formPane.add(cvvField, 1, 3);

        // Pay button with styling
        Button payButton = new Button("Pay");
        payButton.getStyleClass().add("button"); // Applying button style from style.css
        payButton.setOnAction(event -> {
            if (validateForm(nameField, cardNumberField, expiryField, cvvField)) {
                processPayment();
            }
        });

        // Back button with styling
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button"); // Applying button style from style.css
        backButton.setOnAction(event -> {
            // Go back to PaymentPage (assuming you have a PaymentPage class)
            PaymentPage paymentPage = new PaymentPage(stage, loggedInUsername, selectedProperty);
            paymentPage.showPaymentPage();
        });

        // VBox root container with styling
        VBox root = new VBox(20, headingLabel, formPane, payButton, backButton);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("vbox"); // Applying vbox style from style.css

        // Scene setup
        Scene scene = new Scene(root, 400, 400);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); // Applying external CSS file

        stage.setScene(scene);
        stage.setTitle("Card Payment");
        stage.show();
    }

    private boolean validateForm(TextField nameField, TextField cardNumberField, TextField expiryField, PasswordField cvvField) {
        if (nameField.getText().isEmpty() || cardNumberField.getText().isEmpty() || expiryField.getText().isEmpty() || cvvField.getText().isEmpty()) {
            showErrorAlert("Validation Error", "All fields are required.");
            return false;
        }
        if (cardNumberField.getText().length() != 16 || !cardNumberField.getText().matches("\\d+")) {
            showErrorAlert("Validation Error", "Card number must be 16 digits.");
            return false;
        }
        if (!expiryField.getText().matches("\\d{2}/\\d{2}")) {
            showErrorAlert("Validation Error", "Expiry date must follow MM/YY format.");
            return false;
        }
        if (cvvField.getText().length() != 3 || !cvvField.getText().matches("\\d+")) {
            showErrorAlert("Validation Error", "CVV must be 3 digits.");
            return false;
        }
        return true;
    }

    private void processPayment() {
        try {
            // Save the transaction to the database
            TransactionDAO transactionDAO = new TransactionDAO();
            transactionDAO.saveTransaction(loggedInUsername, selectedProperty);

            // Show success dialog
            Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
            successAlert.setTitle("Payment Successful");
            successAlert.setHeaderText(null);
            successAlert.setContentText("Payment was successful!");
            successAlert.showAndWait();

            // Navigate to HomePage
            HomePage homePage = new HomePage(stage, loggedInUsername);
            homePage.showHomePage();
        } catch (Exception e) {
            e.printStackTrace();
            showErrorAlert("Payment Error", "An error occurred while processing the payment.");
        }
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
