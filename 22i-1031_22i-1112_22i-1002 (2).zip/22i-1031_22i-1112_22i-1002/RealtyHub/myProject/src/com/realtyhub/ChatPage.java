package com.realtyhub;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.control.cell.PropertyValueFactory;

public class ChatPage {
    
    private Stage chatStage;
    
    public ChatPage(Stage primaryStage) {
        this.chatStage = primaryStage;
    }
    
    public void showChatPage(String sender, String receiver, int propertyID) {
        chatStage.setTitle("Chat with " + receiver);

        // TableView for displaying messages
        TableView<Message> tableView = new TableView<>();
        
        // Column for sender
        TableColumn<Message, String> senderColumn = new TableColumn<>("Sender");
        senderColumn.setCellValueFactory(new PropertyValueFactory<>("sender"));
        senderColumn.setPrefWidth(100); // Narrower column for sender
        
        // Column for message content
        TableColumn<Message, String> messageColumn = new TableColumn<>("Message");
        messageColumn.setCellValueFactory(new PropertyValueFactory<>("content"));
        messageColumn.setPrefWidth(400); // Wider column for message
        
        tableView.getColumns().addAll(senderColumn, messageColumn);

        // Load existing messages into the table
        populateTable(tableView, sender, receiver, propertyID);

        // Text area for entering a new message
        Label enterMessageLabel = new Label("Enter Message:");
        enterMessageLabel.getStyleClass().add("label-title"); // Apply label styling from style.css
        
        TextArea messageTextArea = new TextArea();
        messageTextArea.setPromptText("Type your message here...");
        messageTextArea.setWrapText(true);
        messageTextArea.getStyleClass().add("text-field"); // Style the text area like a text field

        // Send button to send the message
        Button sendButton = new Button("Send");
        sendButton.getStyleClass().add("button"); // Apply button style
        sendButton.setOnAction(e -> {
            String messageContent = messageTextArea.getText().trim();
            if (!messageContent.isEmpty()) {
                sendMessage(sender, receiver, propertyID, messageContent);
                populateTable(tableView, sender, receiver, propertyID); // Refresh the table
                messageTextArea.clear(); // Clear the text area after sending
            }
        });
        
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button"); // Apply button style
        backButton.setOnAction(e -> {
            HomePage homePage = new HomePage(chatStage, sender);
            homePage.showHomePage();
        });

        // Layout for the chat page
        VBox layout = new VBox(10); // Spacing between elements
        layout.setPadding(new Insets(20)); // Add padding to the layout
        layout.setAlignment(Pos.CENTER); // Center elements in the VBox
        layout.getStyleClass().add("vbox"); // Apply VBox styling from style.css

        layout.getChildren().addAll(
                tableView, 
                enterMessageLabel, 
                messageTextArea, 
                sendButton, 
                backButton
        );

        // Create a Scene for the Chat Page with the specified size
        Scene scene = new Scene(layout, 600, 400); // Set preferred width and height
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); // Apply external CSS
        chatStage.setScene(scene);
        chatStage.show();
    }
    
    // Populate the table with messages
    private void populateTable(TableView<Message> tableView, String sender, String receiver, int propertyID) {
        tableView.getItems().clear();
        
        MessageDAO messageDAO = new MessageDAO();
        try {
            tableView.getItems().addAll(messageDAO.getMessages(sender, receiver));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Send a message
    private void sendMessage(String sender, String receiver, int propertyID, String messageContent) {
        MessageDAO messageDAO = new MessageDAO();
        try {
            messageDAO.sendMessage(sender, receiver, propertyID, messageContent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
