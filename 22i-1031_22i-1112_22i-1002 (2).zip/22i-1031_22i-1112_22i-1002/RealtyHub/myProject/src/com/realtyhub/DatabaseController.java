package com.realtyhub;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseController {
    private static DatabaseController instance;
    private Connection connection;

    private DatabaseController() {
        try {
            connection = DriverManager.getConnection(
            		"jdbc:mysql://localhost:3306/RealtyHubDB",
                "root",
                "iamaazib63"
            );
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static DatabaseController getInstance() {
        if (instance == null) {
            instance = new DatabaseController();
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }

    public PreparedStatement prepareStatement(String query) throws SQLException {
        return connection.prepareStatement(query);
    }

    public void close() {
        try {
            if (connection != null) connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}