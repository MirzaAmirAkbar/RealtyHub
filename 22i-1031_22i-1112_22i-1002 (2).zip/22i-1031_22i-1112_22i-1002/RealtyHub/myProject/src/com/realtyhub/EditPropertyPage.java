package com.realtyhub;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

public class EditPropertyPage {
    private Stage stage;
    private String loggedInUsername;
    private Property selectedProperty;

    public EditPropertyPage(Stage primaryStage, String loggedInUsername, Property selectedProperty) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
        this.selectedProperty = selectedProperty;
    }

    public void showEditPropertyPage() {
        // Create a label for the heading
        Label headingLabel = new Label("Edit Property");
        headingLabel.getStyleClass().add("label-title");

        // Add padding and alignment for the heading
        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);

        // Editable fields for property details
        Label propertyTypeLabel = new Label("Property Type:");
        TextField propertyTypeField = new TextField(selectedProperty.getPropertyType());

        Label addressLabel = new Label("Address:");
        TextField addressField = new TextField(selectedProperty.getPropertyAddress());

        Label transactionTypeLabel = new Label("Transaction Type (Rent/Sale):");
        ComboBox<String> transactionTypeDropdown = new ComboBox<>();
        transactionTypeDropdown.getItems().addAll("Rent", "Sale");
        transactionTypeDropdown.setValue(selectedProperty.getRentOrSale());

        Label priceLabel = new Label("Price:");
        TextField priceField = new TextField(String.valueOf(selectedProperty.getPrice()));

        PropertyDAO propertyDAO = new PropertyDAO();

        // Save button to update the property details
        Button saveButton = new Button("Save Changes");
        saveButton.getStyleClass().add("button");
        saveButton.setOnAction(event -> {
            boolean isUpdated = propertyDAO.updatePropertyInDatabase(
                    selectedProperty.getId(),
                    propertyTypeField.getText(),
                    addressField.getText(),
                    transactionTypeDropdown.getValue(),
                    priceField.getText()
            );

            if (isUpdated) {
                // Update the selectedProperty object with the new values
                selectedProperty.setPropertyType(propertyTypeField.getText());
                selectedProperty.setPropertyAddress(addressField.getText());
                selectedProperty.setRentOrSale(transactionTypeDropdown.getValue());
                selectedProperty.setPrice(Integer.parseInt(priceField.getText()));

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Success");
                alert.setHeaderText("Property Updated");
                alert.setContentText("The property details have been successfully updated and set to 'Not Verified'.");
                alert.showAndWait();

                // Return to Manage Properties Page
                new ManagePropertiesPage(stage, loggedInUsername).showManagePropertiesPage();
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Update Failed");
                alert.setContentText("Could not update the property. Please try again.");
                alert.showAndWait();
            }
        });

        // Back button to return to Manage Properties Page
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button");
        backButton.setOnAction(event -> {
            new ManagePropertiesPage(stage, loggedInUsername).showManagePropertiesPage();
        });

        // Layout
        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(
                propertyTypeLabel, propertyTypeField,
                addressLabel, addressField,
                transactionTypeLabel, transactionTypeDropdown,
                priceLabel, priceField,
                saveButton, backButton
        );

        // Add the custom styling to text fields
        propertyTypeField.getStyleClass().add("text-field");
        addressField.getStyleClass().add("text-field");
        priceField.getStyleClass().add("text-field");
        transactionTypeDropdown.getStyleClass().add("combo-box");

        // Create the root layout and apply custom styling via CSS class
        BorderPane root = new BorderPane();
        root.setTop(headingPane);
        root.setCenter(layout);
        root.getStyleClass().add("edit-property-page");

        // Create a Scene for the Manage Property Page
        Scene managePropertyScene = new Scene(root, 600, 600);

        // Set the CSS stylesheet
        managePropertyScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Set the Scene for the Stage
        stage.setScene(managePropertyScene);
        stage.setTitle("Edit Property");
        stage.show();
    }
}
