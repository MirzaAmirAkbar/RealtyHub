package com.realtyhub;

import javafx.beans.property.*;

public class Feedback {
    private final IntegerProperty feedbackID;
    private final StringProperty feedbackGiver;
    private final StringProperty feedbackReceiver;
    private final IntegerProperty rating;
    private final StringProperty feedbackDescription;

    // Constructor
    public Feedback(int feedbackID, String feedbackGiver, String feedbackReceiver, int rating, String feedbackDescription) {
        this.feedbackID = new SimpleIntegerProperty(feedbackID);
        this.feedbackGiver = new SimpleStringProperty(feedbackGiver);
        this.feedbackReceiver = new SimpleStringProperty(feedbackReceiver);
        this.rating = new SimpleIntegerProperty(rating);
        this.feedbackDescription = new SimpleStringProperty(feedbackDescription);
    }

    // Getters and setters for Feedback ID
    public int getFeedbackID() {
        return feedbackID.get();
    }

    public void setFeedbackID(int feedbackID) {
        this.feedbackID.set(feedbackID);
    }

    public IntegerProperty feedbackIDProperty() {
        return feedbackID;
    }

    // Getters and setters for Feedback Giver
    public String getFeedbackGiver() {
        return feedbackGiver.get();
    }

    public void setFeedbackGiver(String feedbackGiver) {
        this.feedbackGiver.set(feedbackGiver);
    }

    public StringProperty feedbackGiverProperty() {
        return feedbackGiver;
    }

    // Getters and setters for Feedback Receiver
    public String getFeedbackReceiver() {
        return feedbackReceiver.get();
    }

    public void setFeedbackReceiver(String feedbackReceiver) {
        this.feedbackReceiver.set(feedbackReceiver);
    }

    public StringProperty feedbackReceiverProperty() {
        return feedbackReceiver;
    }

    // Getters and setters for Rating
    public int getRating() {
        return rating.get();
    }

    public void setRating(int rating) {
        this.rating.set(rating);
    }

    public IntegerProperty ratingProperty() {
        return rating;
    }

    // Getters and setters for Feedback Description
    public String getFeedbackDescription() {
        return feedbackDescription.get();
    }

    public void setFeedbackDescription(String feedbackDescription) {
        this.feedbackDescription.set(feedbackDescription);
    }

    public StringProperty feedbackDescriptionProperty() {
        return feedbackDescription;
    }
}
