package com.realtyhub;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableView;

public class FeedbackDAO {
	private DatabaseController dbController = DatabaseController.getInstance();
	
    public int submitFeedback(String username, Integer propertyID, String receiver, int rating, String description) {
        try (Connection connection = DriverManager.getConnection("jdbc:sqlserver://AMIRAKBAR\\SQLEXPRESS:1433;databaseName=RealtyHubDB;encrypt=false;",
                "amir",
                "amir123")) {
            String query = "INSERT INTO Feedback (FeedbackGiver, FeedbackReceiver, Rating, FeedbackDescription, PropertyID) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, username);
                stmt.setString(2, receiver);
                stmt.setInt(3, rating);
                stmt.setString(4, description);
                stmt.setInt(5, propertyID);
                stmt.executeUpdate();
                
                return 0;
            }
        } catch (SQLException e) {
            e.getStackTrace();
        }
        
        return 1;
    }
    
    public String fetchFeedbackReceiver(int propertyID, String userType) {
	        String query;
	        if ("Buyer".equalsIgnoreCase(userType)) {
	            query = "SELECT seller FROM Transactions WHERE property_id = ?";
	        } else {
	            query = "SELECT buyer FROM Transactions WHERE property_id = ?";
	        }
	        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
	            stmt.setInt(1, propertyID);
	            ResultSet rs = stmt.executeQuery();
	            if (rs.next()) {
	                return rs.getString(1);
	            }
	        }
	    catch (SQLException e) {
	        e.getStackTrace();
	    }
	    return null;
	}
    
    public void loadTransactionProperties(ComboBox<Integer> comboBox, String username, String userType) {
	        String query;
	        if ("Buyer".equalsIgnoreCase(userType)) {
	            query = "SELECT property_id FROM Transactions WHERE buyer = ?";
	        } else {
	            query = "SELECT property_id FROM Transactions WHERE seller = ?";
	        }
	        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
	            stmt.setString(1, username);
	            ResultSet rs = stmt.executeQuery();
	            while (rs.next()) {
	                comboBox.getItems().add(rs.getInt("property_id"));
	            }
	        }
	    catch (SQLException e) {
	        e.getStackTrace();
	    }
	}
    
    public void loadFeedbackData(TableView<Feedback> table, String username) {
        ObservableList<Feedback> feedbackList = FXCollections.observableArrayList();
        
            String query = "SELECT * FROM Feedback WHERE FeedbackReceiver = ?";
            try (PreparedStatement stmt = dbController.prepareStatement(query)) {
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    feedbackList.add(new Feedback(
                            rs.getInt("FeedbackID"),
                            rs.getString("FeedbackGiver"),
                            rs.getString("FeedbackReceiver"),
                            rs.getInt("Rating"),
                            rs.getString("FeedbackDescription")
                    ));
                }
            }
        catch (SQLException e) {
            e.getStackTrace();
        }
        table.setItems(feedbackList);
    }
}