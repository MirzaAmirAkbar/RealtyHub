package com.realtyhub;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class FeedbackPage {

    private Stage stage;
    private String loggedInUsername;
    private String userType;

    public FeedbackPage(Stage stage, String loggedInUsername, String userType) {
        this.stage = stage;
        this.loggedInUsername = loggedInUsername;
        this.userType = userType;
    }

    public void showFeedbackPage() {
        FeedbackDAO feedbackDAO = new FeedbackDAO();

        // Main VBox with background styling
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.getStyleClass().add("vbox");

        // Page Title
        Label headingLabel = new Label("Feedback Page");
        headingLabel.getStyleClass().add("label-title");

        // Feedback Table
        TableView<Feedback> feedbackTable = new TableView<>();
        feedbackTable.setPlaceholder(new Label("No feedback available."));
        setupFeedbackTable(feedbackTable);

        feedbackTable.setMinHeight(100);
        feedbackTable.setPrefHeight(200);

        // Add table to a container with explicit VBox constraints
        VBox tableContainer = new VBox(feedbackTable);
        tableContainer.setVgrow(feedbackTable, Priority.ALWAYS); // Ensures the table grows
        feedbackDAO.loadFeedbackData(feedbackTable, loggedInUsername);

        // Submit Feedback Section
        Label submitFeedbackLabel = new Label("Submit Feedback");
        submitFeedbackLabel.getStyleClass().add("label-title");

        ComboBox<Integer> propertyIDField = new ComboBox<>();
        propertyIDField.setPromptText("Select Property ID");
        propertyIDField.getStyleClass().add("combo-box");
        feedbackDAO.loadTransactionProperties(propertyIDField, loggedInUsername, userType);

        Label feedbackReceiverLabel = new Label("Feedback Receiver: ");
        TextField feedbackReceiverField = new TextField();
        feedbackReceiverField.setEditable(false);
        feedbackReceiverField.getStyleClass().add("text-field");

        propertyIDField.setOnAction(event -> {
            Integer selectedPropertyID = propertyIDField.getValue();
            if (selectedPropertyID != null) {
                String feedbackReceiver = feedbackDAO.fetchFeedbackReceiver(selectedPropertyID, userType);
                feedbackReceiverField.setText(feedbackReceiver != null ? feedbackReceiver : "Not found");
            }
        });

        Slider ratingSlider = new Slider(1, 10, 5);
        ratingSlider.setShowTickMarks(true);
        ratingSlider.setShowTickLabels(true);
        ratingSlider.setMajorTickUnit(1);

        TextArea feedbackDescriptionField = new TextArea();
        feedbackDescriptionField.setPromptText("Write your feedback here...");
        feedbackDescriptionField.setWrapText(true);

        Button submitFeedbackButton = new Button("Submit Feedback");
        submitFeedbackButton.getStyleClass().add("button");
        submitFeedbackButton.setOnAction(event -> {
            if (propertyIDField.getValue() == null || feedbackReceiverField.getText().isEmpty() || feedbackDescriptionField.getText().isEmpty()) {
                showAlert(Alert.AlertType.WARNING, "Warning", "Please fill all the fields!");
            } else {
                int validation = feedbackDAO.submitFeedback(
                        loggedInUsername,
                        propertyIDField.getValue(),
                        feedbackReceiverField.getText(),
                        (int) ratingSlider.getValue(),
                        feedbackDescriptionField.getText()
                );
                if (validation == 0) {
                    showAlert(Alert.AlertType.INFORMATION, "Success", "Feedback submitted successfully!");
                } else {
                    showAlert(Alert.AlertType.ERROR, "Error", "Error submitting feedback");
                }
                feedbackDAO.loadFeedbackData(feedbackTable, loggedInUsername);
            }
        });

        VBox submitFeedbackForm = new VBox(10, propertyIDField, feedbackReceiverLabel, feedbackReceiverField, ratingSlider, feedbackDescriptionField, submitFeedbackButton);
        submitFeedbackForm.getStyleClass().add("vbox");
        submitFeedbackForm.setPadding(new Insets(10));
        submitFeedbackForm.setStyle("-fx-border-color: #90CAF9;");

        root.getChildren().addAll(headingLabel, tableContainer, submitFeedbackLabel, submitFeedbackForm);

        // Back Button
        Button backButton = new Button("Back to Home");
        backButton.getStyleClass().add("button");
        backButton.setOnAction(event -> {
            HomePage homePage = new HomePage(stage, loggedInUsername);
            homePage.showHomePage();
        });

        root.getChildren().add(backButton);

        Scene feedbackScene = new Scene(root, 800, 700);
        feedbackScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        stage.setScene(feedbackScene);
        stage.setTitle("Feedback Page");
        stage.show();
    }


    private void setupFeedbackTable(TableView<Feedback> table) {
    	
        TableColumn<Feedback, Integer> idColumn = new TableColumn<>("Feedback ID");
        idColumn.setCellValueFactory(cellData -> cellData.getValue().feedbackIDProperty().asObject());

        TableColumn<Feedback, String> giverColumn = new TableColumn<>("Feedback Giver");
        giverColumn.setCellValueFactory(cellData -> cellData.getValue().feedbackGiverProperty());

        TableColumn<Feedback, String> receiverColumn = new TableColumn<>("Feedback Receiver");
        receiverColumn.setCellValueFactory(cellData -> cellData.getValue().feedbackReceiverProperty());

        TableColumn<Feedback, Integer> ratingColumn = new TableColumn<>("Rating");
        ratingColumn.setCellValueFactory(cellData -> cellData.getValue().ratingProperty().asObject());

        TableColumn<Feedback, String> descriptionColumn = new TableColumn<>("Description");
        descriptionColumn.setCellValueFactory(cellData -> cellData.getValue().feedbackDescriptionProperty());

        table.getColumns().addAll(idColumn, giverColumn, receiverColumn, ratingColumn, descriptionColumn);
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
