package com.realtyhub;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class HomePage {

    private Stage stage;
    private String loggedInUsername;
    String userType = "";

    // Constructor accepts Stage and logged-in username
    public HomePage(Stage primaryStage, String loggedInUsername) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
    }

    public void showHomePage() {
        UserDAO userDAO = new UserDAO();
        userType = userDAO.getUserType(loggedInUsername);

        // Create a label for the heading
        Label headingLabel = new Label("Home Page");
        headingLabel.getStyleClass().add("label-title");

        // Create the buttons
        Button manageProfileButton = new Button("Manage Profile");
        Button manageViewPropertiesButton = new Button(userType.equalsIgnoreCase("buyer") ? "View Properties" : "Manage Properties");
        Button feedbackButton = new Button("Feedbacks");
        Button viewVisitsButton = new Button("View Visits");
        Button messagesButton = new Button("Messages");
        Button approvePropertiesButton = new Button("Approve Properties");
        Button logOutButton = new Button("Log Out");

        // Apply CSS class to buttons
        manageProfileButton.getStyleClass().add("button");
        manageViewPropertiesButton.getStyleClass().add("button");
        feedbackButton.getStyleClass().add("button");
        viewVisitsButton.getStyleClass().add("button");
        messagesButton.getStyleClass().add("button");
        approvePropertiesButton.getStyleClass().add("button");
        logOutButton.getStyleClass().add("button");

        // Add button actions
        manageProfileButton.setOnAction(event -> {
            ManageProfilePage manageProfilePage = new ManageProfilePage(stage, loggedInUsername);
            manageProfilePage.showManageProfilePage();
        });
        manageViewPropertiesButton.setOnAction(event -> {
            if (userType.equalsIgnoreCase("buyer")) {
                ViewPropertiesPage viewPropertiesPage = new ViewPropertiesPage(stage, loggedInUsername);
                viewPropertiesPage.showViewPropertiesPage();
            } else {
                ManagePropertiesPage managePropertiesPage = new ManagePropertiesPage(stage, loggedInUsername);
                managePropertiesPage.showManagePropertiesPage();
            }
        });
        feedbackButton.setOnAction(event -> {
            FeedbackPage feedbackPage = new FeedbackPage(stage, loggedInUsername, userType);
            feedbackPage.showFeedbackPage();
        });
        viewVisitsButton.setOnAction(event -> {
            ViewVisitsPage viewVisitsPage = new ViewVisitsPage(stage, loggedInUsername);
            viewVisitsPage.showViewVisitsPage();
        });
        messagesButton.setOnAction(event -> {
            MessagesPage messagesPage = new MessagesPage(stage);
            messagesPage.showMessagesPage(loggedInUsername);
        });
        approvePropertiesButton.setOnAction(event -> {
            ApprovePropertiesPage approvePropertiesPage = new ApprovePropertiesPage(stage, loggedInUsername);
            approvePropertiesPage.showApprovePropertiesPage();
        });
        logOutButton.setOnAction(event -> {
            StartPage startPage = new StartPage();
            startPage.start(stage);
        });

        // Create a VBox container for buttons and center them
        VBox buttonBox = new VBox(15);
        buttonBox.setAlignment(Pos.CENTER);
        buttonBox.getChildren().addAll(manageProfileButton, manageViewPropertiesButton, feedbackButton, viewVisitsButton, messagesButton);

        if (userType.equalsIgnoreCase("admin")) {
            buttonBox.getChildren().clear();
            buttonBox.getChildren().addAll(approvePropertiesButton, logOutButton);
        } else {
            buttonBox.getChildren().add(logOutButton);
        }

        // Root layout with heading and centered buttons
        BorderPane root = new BorderPane();
        root.setTop(headingLabel);
        BorderPane.setAlignment(headingLabel, Pos.CENTER);
        root.setCenter(buttonBox);
        root.setStyle("-fx-background-color: #87CEEB;"); // Match VBox background color

        // Create the Scene with centralized layout
        Scene homeScene = new Scene(root, 600, 500);
        homeScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Set the Stage
        stage.setScene(homeScene);
        stage.setTitle("Home Page");
        stage.show();
    }

    // Utility method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
