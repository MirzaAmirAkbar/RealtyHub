package com.realtyhub;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class LoginPage {

    private Stage stage; // Reference to the primary stage

    // Constructor accepts Stage to allow switching scenes
    public LoginPage(Stage primaryStage) {
        this.stage = primaryStage;
    }

    public void showLoginPage() {
        // Create labels and input fields for login
        Label usernameLabel = new Label("Username: ");
        usernameLabel.getStyleClass().add("label-title");

        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter username");
        usernameField.getStyleClass().add("text-field");

        Label passwordLabel = new Label("Password: ");
        passwordLabel.getStyleClass().add("label-title");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");
        passwordField.getStyleClass().add("password-field");

        // Create a Submit button
        Button submitButton = new Button("Submit");
        submitButton.setPrefWidth(200); // Wider button
        submitButton.getStyleClass().add("button");

        // Create a Back button
        Button backButton = new Button("Back");
        backButton.setPrefWidth(200); // Wider button
        backButton.getStyleClass().add("button");

        // Label to display validation messages
        Label feedbackLabel = new Label();
        feedbackLabel.getStyleClass().add("label-title");

        // Handle the Submit button action
        submitButton.setOnAction(event -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            // Validate login using RealtyHub's login method
            UserDAO userDAO = new UserDAO();
            int validation = userDAO.login(username, password);

            switch (validation) {
                case -1:
                    feedbackLabel.setStyle("-fx-text-fill: red;");
                    feedbackLabel.setText("Error reading user data!");
                    break;
                case 0:
                    Alert successDialog = new Alert(Alert.AlertType.INFORMATION);
                    successDialog.setTitle("Login Success");
                    successDialog.setHeaderText(null);
                    successDialog.setContentText("Logged in successfully!");
                    successDialog.showAndWait();

                    HomePage homePage = new HomePage(stage, username);
                    homePage.showHomePage();
                    break;
                case 1:
                    feedbackLabel.setStyle("-fx-text-fill: red;");
                    feedbackLabel.setText("Incorrect Username!");
                    break;
                case 2:
                    feedbackLabel.setStyle("-fx-text-fill: red;");
                    feedbackLabel.setText("Incorrect Password!");
                    break;
            }
        });

        backButton.setOnAction(event -> {
            StartPage startPage = new StartPage();
            startPage.start(stage);
        });

        // Button layout (Submit and Back buttons)
        VBox buttonBox = new VBox(10); // Spacing between buttons
        buttonBox.setAlignment(Pos.CENTER); // Center alignment
        buttonBox.getChildren().addAll(submitButton, backButton);

        // Main layout (all elements)
        VBox vbox = new VBox(15); // Spacing between elements
        vbox.setPadding(new Insets(20));
        vbox.setAlignment(Pos.CENTER); // Center alignment
        vbox.getStyleClass().add("vbox"); // Apply VBox style

        // Add all elements to the VBox
        vbox.getChildren().addAll(usernameLabel, usernameField, passwordLabel, passwordField, feedbackLabel, buttonBox);

        // Center the VBox within the Scene
        StackPane centerPane = new StackPane();
        centerPane.getChildren().add(vbox);

        // Create a Scene for the Login Page
        Scene loginScene = new Scene(centerPane, 500, 450);

        // Add the CSS file to the scene
        loginScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Set the new Scene for the Stage
        stage.setScene(loginScene);
        stage.setTitle("Login Page");
        stage.show();
    }
}
