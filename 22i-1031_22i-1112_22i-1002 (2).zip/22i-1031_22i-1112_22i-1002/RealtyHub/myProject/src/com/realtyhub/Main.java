package com.realtyhub;

public class Main {
	
    public static void main(String[] args) {
        RealtyHub.begin(args);
    }
    
}
