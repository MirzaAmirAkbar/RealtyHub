package com.realtyhub;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ManageProfilePage {

    private Stage stage;
    private String loggedInUsername;

    public ManageProfilePage(Stage primaryStage, String loggedInUsername) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
    }

    public void showManageProfilePage() {
        // Create labels and input fields for user details
        Label emailLabel = new Label("Email:");
        emailLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        TextField emailField = new TextField();
        emailField.setPromptText("Email");
        emailField.setMaxWidth(300);
        emailField.setDisable(true);
        emailField.setStyle("-fx-border-color: #007acc; -fx-border-radius: 5px; -fx-padding: 5px;");

        Label addressLabel = new Label("Address:");
        addressLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        TextArea addressArea = new TextArea();
        addressArea.setPromptText("Address");
        addressArea.setMaxWidth(300);
        addressArea.setMaxHeight(80);
        addressArea.setDisable(true);
        addressArea.setStyle("-fx-border-color: #007acc; -fx-border-radius: 5px; -fx-padding: 5px;");

        Label contactLabel = new Label("Contact Number:");
        contactLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");
        TextField contactField = new TextField();
        contactField.setPromptText("Contact Number");
        contactField.setMaxWidth(300);
        contactField.setDisable(true);
        contactField.setStyle("-fx-border-color: #007acc; -fx-border-radius: 5px; -fx-padding: 5px;");

        // Create buttons
        Button saveButton = new Button("Save Changes");
        saveButton.setStyle("-fx-background-color: #2196F3; -fx-text-fill: white; -fx-padding: 8 16; -fx-font-size: 14px; -fx-border-radius: 5px;");
        saveButton.setDisable(true);

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 8 16; -fx-font-size: 14px; -fx-border-radius: 5px;");

        // Fetch user details based on the logged-in username
        UserDAO userDAO = new UserDAO();
        String[] userDetails = userDAO.fetchUserDetails(loggedInUsername);
        
        if (userDetails == null) {
        	showAlert(Alert.AlertType.ERROR, "Error", "Error fetching user details");
        }
        else {
        	emailField.setText(userDetails[0]);
        	addressArea.setText(userDetails[1]);
        	contactField.setText(userDetails[2]);
        	
            // Enable fields and save button
            emailField.setDisable(false);
            addressArea.setDisable(false);
            contactField.setDisable(false);
            saveButton.setDisable(false);
        }

        // Save updated details to the database
        saveButton.setOnAction(event -> {
            String email = emailField.getText();
            String address = addressArea.getText();
            String contact = contactField.getText();

            // Validate input fields
            if (email.isEmpty() || address.isEmpty() || contact.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Error", "All fields must be filled!");
                return;
            }
            
            int validation = userDAO.updateUserDetails(email, address, contact, loggedInUsername);
            
            switch(validation) {
            case 0:
            	showAlert(Alert.AlertType.INFORMATION, "Success", "Profile updated successfully!");
            	break;
            case 1:
            	showAlert(Alert.AlertType.ERROR, "Error", "Failed to update profile.");
            	break;
            }
        });

        // Back button functionality
        backButton.setOnAction(event -> {
            HomePage homePage = new HomePage(stage,loggedInUsername);
            homePage.showHomePage();
        });

        // Layout
        VBox root = new VBox(15); // Spacing between elements
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #87CEEB; -fx-border-radius: 10px; -fx-border-color: #007acc; -fx-border-width: 2px;");

        root.getChildren().addAll(
                emailLabel, emailField,
                addressLabel, addressArea,
                contactLabel, contactField,
                saveButton, backButton
        );

        // Set up the scene
        Scene scene = new Scene(root, 400, 500);
        stage.setScene(scene);
        stage.setTitle("Manage Profile");
        stage.show();
    }

    // Utility method to show alerts
    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
