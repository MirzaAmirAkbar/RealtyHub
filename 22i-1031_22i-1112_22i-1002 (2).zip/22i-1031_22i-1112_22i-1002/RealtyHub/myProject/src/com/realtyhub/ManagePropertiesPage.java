package com.realtyhub;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ManagePropertiesPage {
    private Stage stage;
    private String loggedInUsername;

    public ManagePropertiesPage(Stage primaryStage, String loggedInUsername) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
    }

    public void showManagePropertiesPage() {
        // Create a label for the heading
        Label headingLabel = new Label("Manage Properties");
        headingLabel.getStyleClass().add("label-title");

        // Add padding and alignment for the heading
        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);

        // TableView to display properties
        TableView<Property> propertiesTable = new TableView<>();
        propertiesTable.setPrefHeight(300);

        // Define columns
        TableColumn<Property, Integer> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Property, String> typeColumn = new TableColumn<>("Property Type");
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("propertyType"));

        TableColumn<Property, String> addressColumn = new TableColumn<>("Address");
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("propertyAddress"));

        TableColumn<Property, String> transactionColumn = new TableColumn<>("Transaction Type");
        transactionColumn.setCellValueFactory(new PropertyValueFactory<>("rentOrSale"));

        TableColumn<Property, Integer> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Property, String> verifiedColumn = new TableColumn<>("Verified");
        verifiedColumn.setCellValueFactory(new PropertyValueFactory<>("verifiedStatus"));

        // Add columns to the table
        propertiesTable.getColumns().addAll(idColumn, typeColumn, addressColumn, transactionColumn, priceColumn, verifiedColumn);

        // Load properties from the database
        PropertyDAO propertyDAO = new PropertyDAO();
        ObservableList<Property> propertyList = propertyDAO.loadPropertiesFromDatabase(loggedInUsername);
        propertiesTable.setItems(propertyList);

        // Buttons at the bottom
        Button addPropertyButton = new Button("Add Property");
        addPropertyButton.getStyleClass().add("button"); // Applying button style

        addPropertyButton.setOnAction(event -> {
            new AddPropertiesPage(stage, loggedInUsername).showAddPropertiesPage();
        });

        Button removePropertyButton = new Button("Remove Property");
        removePropertyButton.getStyleClass().add("button"); // Applying button style

        removePropertyButton.setOnAction(event -> {
            Property selectedProperty = propertiesTable.getSelectionModel().getSelectedItem();
            if (selectedProperty != null) {
                propertyDAO.removePropertyFromDatabase(selectedProperty.getId());
                propertyList.setAll(propertyDAO.loadPropertiesFromDatabase(loggedInUsername)); // Refresh the table
            } else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("No Property Selected");
                alert.setHeaderText(null);
                alert.setContentText("Please select a property to remove.");
                alert.showAndWait();
            }
        });

        Button editPropertyButton = new Button("Edit Property");
        editPropertyButton.getStyleClass().add("button"); // Applying button style

        editPropertyButton.setOnAction(event -> {
            Property selectedProperty = propertiesTable.getSelectionModel().getSelectedItem();
            if (selectedProperty != null) {
                // Pass the selected property to the EditPropertyPage
                EditPropertyPage editPropertyPage = new EditPropertyPage(stage, loggedInUsername, selectedProperty);
                editPropertyPage.showEditPropertyPage();
            } else {
                // Show an alert if no property is selected
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("No Property Selected");
                alert.setHeaderText(null);
                alert.setContentText("Please select a property to edit.");
                alert.showAndWait();
            }
        });

        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button"); // Applying button style

        backButton.setOnAction(event -> {
            // Navigate back to HomePage
            HomePage homePage = new HomePage(stage, loggedInUsername);
            homePage.showHomePage();
        });

        HBox buttonBox = new HBox(20);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));
        buttonBox.getChildren().addAll(addPropertyButton, removePropertyButton, editPropertyButton, backButton);

        // Create a layout
        VBox centerBox = new VBox(20);
        centerBox.setPadding(new Insets(20));
        centerBox.getChildren().addAll(propertiesTable, buttonBox);

        BorderPane root = new BorderPane();
        root.setTop(headingPane);
        root.setCenter(centerBox);
        root.getStyleClass().add("vbox"); // Apply vbox style

        // Create a Scene for the Manage Properties Page
        Scene managePropertiesScene = new Scene(root, 800, 600);
        managePropertiesScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm()); // Apply external CSS

        // Set the new Scene for the Stage
        stage.setScene(managePropertiesScene);
        stage.setTitle("Manage Properties");
        stage.show();
    }
}
