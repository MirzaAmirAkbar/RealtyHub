package com.realtyhub;

public class Message {
    private String sender;
    private String receiver;
    private String content;
    private int propertyID;

    // Constructor
    public Message(String sender, String receiver, String content, int propertyID) {
        this.sender = sender;
        this.receiver = receiver;
        this.content = content;
        this.propertyID = propertyID;
    }

    // Getter and Setter methods for sender
    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    // Getter and Setter methods for receiver
    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    // Getter and Setter methods for content
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    // Getter and Setter methods for propertyID
    public int getPropertyID() {
        return propertyID;
    }

    public void setPropertyID(int propertyID) {
        this.propertyID = propertyID;
    }
}