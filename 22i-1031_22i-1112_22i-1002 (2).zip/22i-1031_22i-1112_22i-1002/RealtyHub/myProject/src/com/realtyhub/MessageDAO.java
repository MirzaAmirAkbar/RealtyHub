package com.realtyhub;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MessageDAO {
	private DatabaseController dbController = DatabaseController.getInstance();
	
	// Save a new message
    public void sendMessage(String sender, String receiver, int propertyId, String content) throws SQLException {
        String query = "INSERT INTO Messages (sender, receiver, property_id, message_content) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = dbController.prepareStatement(query);
        stmt.setString(1, sender);
        stmt.setString(2, receiver);
        stmt.setInt(3, propertyId);
        stmt.setString(4, content);
        stmt.executeUpdate();
    }
    
 // Get all messages between two users
    public List<Message> getMessages(String user1, String user2) throws SQLException {
        String query = "SELECT * FROM Messages WHERE " +
                       "(sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) " +
                       "ORDER BY sent_at ASC";
        PreparedStatement stmt = dbController.prepareStatement(query);
        stmt.setString(1, user1);
        stmt.setString(2, user2);
        stmt.setString(3, user2);
        stmt.setString(4, user1);

        ResultSet rs = stmt.executeQuery();
        List<Message> messages = new ArrayList<>();
        while (rs.next()) {
            Message msg = new Message(
                rs.getString("sender"),
                rs.getString("receiver"),
                rs.getString("message_content"),
                rs.getInt("property_id")
            );
            messages.add(msg);
        }
        return messages;
    }
    
 // Get all users the logged-in user has chatted with
    public List<String> getChatUsers(String username) throws SQLException {
        String query = "SELECT DISTINCT CASE WHEN sender = ? THEN receiver ELSE sender END AS chatUser " +
                       "FROM Messages WHERE sender = ? OR receiver = ?";
        PreparedStatement stmt = dbController.prepareStatement(query);
        stmt.setString(1, username);
        stmt.setString(2, username);
        stmt.setString(3, username);

        ResultSet rs = stmt.executeQuery();
        List<String> chatUsers = new ArrayList<>();
        while (rs.next()) {
            chatUsers.add(rs.getString("chatUser"));
        }
        return chatUsers;
    }
    
 // Get all property IDs involved in conversations between the logged-in user and another user
    public List<Integer> getPropertyIDs(String username, String chatUser) throws SQLException {
        String query = "SELECT DISTINCT property_id FROM Messages WHERE " +
                       "(sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?)";
        PreparedStatement stmt = dbController.prepareStatement(query);
        stmt.setString(1, username);
        stmt.setString(2, chatUser);
        stmt.setString(3, chatUser);
        stmt.setString(4, username);

        ResultSet rs = stmt.executeQuery();
        List<Integer> propertyIDs = new ArrayList<>();
        while (rs.next()) {
            propertyIDs.add(rs.getInt("property_id"));
        }
        return propertyIDs;
    }
}