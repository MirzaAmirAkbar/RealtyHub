package com.realtyhub;

import java.sql.SQLException;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MessagesPage {

    Stage messagesStage;

    public MessagesPage(Stage stage) {
        this.messagesStage = stage;
    }

    public void showMessagesPage(String username) {
        messagesStage.setTitle("Messages");

        // TableView to display users and corresponding property ID
        TableView<UserChat> tableView = new TableView<>();

        // Column for the chat user
        TableColumn<UserChat, String> userColumn = new TableColumn<>("User");
        userColumn.setCellValueFactory(cellData -> cellData.getValue().getUserNameProperty());
        userColumn.setPrefWidth(200);

        // Column for the property ID
        TableColumn<UserChat, Integer> propertyIdColumn = new TableColumn<>("Property ID");
        propertyIdColumn.setCellValueFactory(cellData -> cellData.getValue().getPropertyIDProperty().asObject());
        propertyIdColumn.setPrefWidth(100);

        tableView.getColumns().addAll(userColumn, propertyIdColumn);

        // Load the chat users into the table
        populateTable(tableView, username);

        // Button to open the chat page
        Button openChatButton = new Button("Open Chat");
        openChatButton.getStyleClass().add("button"); // Apply button style
        openChatButton.setOnAction(e -> {
            UserChat selectedUserChat = tableView.getSelectionModel().getSelectedItem();
            if (selectedUserChat != null) {
                String receiver = selectedUserChat.getUserName();
                int propertyID = selectedUserChat.getPropertyID();
                // Open the chat page with the selected user and property ID
                ChatPage chatPage = new ChatPage(messagesStage);
                chatPage.showChatPage(username, receiver, propertyID);
            }
        });

        // Back Button
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button"); // Apply button style
        backButton.setOnAction(e -> {
            HomePage homePage = new HomePage(messagesStage, username);
            homePage.showHomePage();
        });

        // Layout for the Messages page
        VBox layout = new VBox(10);
        layout.getStyleClass().add("vbox"); // Apply vbox style
        layout.setPadding(new Insets(20)); // Add padding
        layout.getChildren().addAll(tableView, openChatButton, backButton);

        Scene scene = new Scene(layout, 400, 300);
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        messagesStage.setScene(scene);
        messagesStage.show();
    }

    // Populate the table with users and property IDs
    private void populateTable(TableView<UserChat> tableView, String username) {
        MessageDAO messageDAO = new MessageDAO();
        try {
            // Get the list of users the logged-in user has chatted with
            List<String> chatUsers = messageDAO.getChatUsers(username);
            ObservableList<UserChat> userChats = FXCollections.observableArrayList();

            for (String chatUser : chatUsers) {
                // For each user, get the property ID (you can adjust this logic to fetch property ID more effectively)
                List<Integer> propertyIDs = messageDAO.getPropertyIDs(username, chatUser);
                for (int propertyID : propertyIDs) {
                    userChats.add(new UserChat(chatUser, propertyID));
                }
            }
            tableView.setItems(userChats); // Set the items in the table
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
