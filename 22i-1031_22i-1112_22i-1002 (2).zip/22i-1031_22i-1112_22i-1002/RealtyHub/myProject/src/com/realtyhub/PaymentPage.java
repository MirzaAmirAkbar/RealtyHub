package com.realtyhub;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PaymentPage {
    private Stage stage;
    private String loggedInUsername;
    private Property selectedProperty;

    public PaymentPage(Stage primaryStage, String loggedInUsername, Property selectedProperty) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
        this.selectedProperty = selectedProperty;
    }

    public void showPaymentPage() {
        // Validate selectedProperty before proceeding
        if (selectedProperty == null || selectedProperty.getPrice() == 0) {
            showErrorAlert("Invalid Property", "Selected property is null or does not have a valid price.");
            return;
        }

        // Create a label for the heading
        Label headingLabel = new Label("Payment Page");
        headingLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #007acc;");

        // Add padding and alignment for the heading
        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);
        headingPane.setStyle("-fx-background-color: #87CEEB; -fx-border-radius: 10px; -fx-border-color: #007acc; -fx-border-width: 2px;");

        // Invoice Summary Table
        TableView<InvoiceItem> invoiceTable = new TableView<>();
        invoiceTable.setPrefHeight(300);

        // Define columns
        TableColumn<InvoiceItem, String> itemColumn = new TableColumn<>("Item");
        itemColumn.setCellValueFactory(cellData -> cellData.getValue().itemProperty());

        TableColumn<InvoiceItem, String> amountColumn = new TableColumn<>("Amount");
        amountColumn.setCellValueFactory(cellData -> cellData.getValue().amountProperty());

        // Add columns to the table
        invoiceTable.getColumns().addAll(itemColumn, amountColumn);

        // Calculate invoice details (property price + 2% platform fee)
        ObservableList<InvoiceItem> invoiceItems = FXCollections.observableArrayList();
        try {
            double propertyPrice = selectedProperty.getPrice();
            double platformFee = propertyPrice * 0.02;
            double totalAmount = propertyPrice + platformFee;

            invoiceItems.add(new InvoiceItem("Property Price", String.format("$%.2f", propertyPrice)));
            invoiceItems.add(new InvoiceItem("Platform Fee (2%)", String.format("$%.2f", platformFee)));
            invoiceItems.add(new InvoiceItem("Total Amount", String.format("$%.2f", totalAmount)));
        } catch (Exception e) {
            e.printStackTrace();
            showErrorAlert("Calculation Error", "An error occurred while calculating the invoice details.");
        }

        invoiceTable.setItems(invoiceItems);

        // Payment options buttons
        Button bankTransferButton = new Button("Bank Transfer");
        bankTransferButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");
        bankTransferButton.setOnAction(event -> showPaymentConfirmation("Bank Transfer"));

        Button creditCardButton = new Button("Credit/Debit Card");
        creditCardButton.setStyle("-fx-background-color: #4CAF50; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");
        creditCardButton.setOnAction(event -> showPaymentConfirmation("Credit/Debit Card"));
        creditCardButton.setOnAction(event -> {
            CardPaymentPage cardPaymentPage = new CardPaymentPage(stage, loggedInUsername, selectedProperty);
            cardPaymentPage.showCardPaymentPage();
        });

        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #f44336; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");
        backButton.setOnAction(event -> {
            ViewPropertiesPage viewPropertiesPage = new ViewPropertiesPage(stage, loggedInUsername);
            viewPropertiesPage.showViewPropertiesPage();
        });

        // Button container
        HBox buttonBox = new HBox(20);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));
        buttonBox.getChildren().addAll(bankTransferButton, creditCardButton, backButton);

        // Main container
        VBox centerBox = new VBox(20);
        centerBox.setPadding(new Insets(20));
        centerBox.getChildren().addAll(invoiceTable, buttonBox);

        // Create a root layout
        BorderPane root = new BorderPane();
        root.setTop(headingPane);
        root.setCenter(centerBox);
        root.setStyle("-fx-background-color: #87CEEB; -fx-border-radius: 10px; -fx-border-color: #007acc; -fx-border-width: 2px;");

        // Create a Scene for the Payment Page
        Scene paymentScene = new Scene(root, 600, 400);

        // Set the Scene for the Stage
        stage.setScene(paymentScene);
        stage.setTitle("Payment Page");
        stage.show();
    }

    private void showPaymentConfirmation(String paymentMethod) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Payment Method");
        alert.setHeaderText("Payment Confirmation");
        alert.setContentText("You have selected " + paymentMethod + " as your payment method.\nPlease proceed with the transaction.");
        alert.showAndWait();
    }

    private void showErrorAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // InvoiceItem class for the table view
    public static class InvoiceItem {
        private final javafx.beans.property.SimpleStringProperty item;
        private final javafx.beans.property.SimpleStringProperty amount;

        public InvoiceItem(String item, String amount) {
            this.item = new javafx.beans.property.SimpleStringProperty(item);
            this.amount = new javafx.beans.property.SimpleStringProperty(amount);
        }

        public String getItem() {
            return item.get();
        }

        public javafx.beans.property.StringProperty itemProperty() {
            return item;
        }

        public String getAmount() {
            return amount.get();
        }

        public javafx.beans.property.StringProperty amountProperty() {
            return amount;
        }
    }
}
