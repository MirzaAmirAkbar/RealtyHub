package com.realtyhub;

public class Property {
    private int id; // Add the id attribute
    private String propertyType;
    private String propertyAddress;
    private String rentOrSale;
    private int price;
    private String verifiedStatus;
    private boolean verified;
    private String propertyOwner;

    // Constructor with id and String verifiedStatus
    public Property(int id, String propertyOwner, String propertyType, String propertyAddress, String rentOrSale, int price, String verified) {
        this.id = id; // Initialize the id
        this.propertyOwner = propertyOwner;
        this.propertyType = propertyType;
        this.propertyAddress = propertyAddress;
        this.rentOrSale = rentOrSale;
        this.price = price;
        this.verifiedStatus = verified;
        this.verified = "Verified".equalsIgnoreCase(verified); // Set the boolean based on the string value
    }

    // Constructor with id and boolean verified
    public Property(int id, String propertyOwner, String propertyType, String propertyAddress, String rentOrSale, int price, boolean verified) {
        this.id = id; // Initialize the id
        this.propertyOwner = propertyOwner;
        this.propertyType = propertyType;
        this.propertyAddress = propertyAddress;
        this.rentOrSale = rentOrSale;
        this.price = price;
        this.verified = verified;
        this.verifiedStatus = verified ? "Verified" : "Not Verified"; // Set the string based on the boolean value
    }

    // Constructor with String verifiedStatus and no id
    public Property(String propertyOwner, String propertyType, String propertyAddress, String rentOrSale, int price, String verifiedStatus) {
        this.propertyOwner = propertyOwner;
        this.propertyType = propertyType;
        this.propertyAddress = propertyAddress;
        this.rentOrSale = rentOrSale;
        this.price = price;
        this.verifiedStatus = verifiedStatus;
        this.verified = "Verified".equalsIgnoreCase(verifiedStatus); // Set the boolean based on the string value
    }

    // Constructor without id and String verifiedStatus
    public Property(String propertyType, String propertyAddress, String rentOrSale, int price, String verifiedStatus) { 
        this.propertyType = propertyType; 
        this.propertyAddress = propertyAddress; 
        this.rentOrSale = rentOrSale; 
        this.price = price; 
        this.verifiedStatus = verifiedStatus; 
        this.verified = "Verified".equalsIgnoreCase(verifiedStatus); // Set the boolean based on the string value
    }
    
    public Property(int id, String propertyType, String propertyAddress, String rentOrSale, int price, String verifiedStatus) { 
    	this.id = id; // Initialize the id
    	this.propertyType = propertyType; 
        this.propertyAddress = propertyAddress; 
        this.rentOrSale = rentOrSale; 
        this.price = price; 
        this.verifiedStatus = verifiedStatus; 
        this.verified = "Verified".equalsIgnoreCase(verifiedStatus); // Set the boolean based on the string value
    }

    // Getter and Setter for id
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPropertyOwner() {
        return propertyOwner;
    }

    public String getPropertyType() {
        return propertyType;
    }

    public String getPropertyAddress() {
        return propertyAddress;
    }

    public String getRentOrSale() {
        return rentOrSale;
    }

    public int getPrice() {
        return price;
    }

    public String getVerifiedStatus() {
        return verifiedStatus;
    }

    // Setter for verifiedStatus, will update both string and boolean
    public void setVerifiedStatus(String verifiedStatus) {
        this.verifiedStatus = verifiedStatus;
        this.verified = "Verified".equalsIgnoreCase(verifiedStatus); // Sync boolean with string
    }

    // Getter for boolean verified
    public boolean isVerified() {
        return verified;
    }

    // Setter for verified, will update both boolean and string
    public void setVerified(boolean verified) {
        this.verified = verified;
        this.verifiedStatus = verified ? "Verified" : "Not Verified"; // Sync string with boolean
    }

	public void setPropertyType(String propertyType2) {
		this.propertyType = propertyType2;
		
	}

	public void setRentOrSale(String transactionType) {
		this.rentOrSale = transactionType;
		
	}

	public void setPrice(int int1) {
		this.price = int1;
		
	}

	public void setPropertyAddress(String address) {
		this.propertyAddress = address;
		
	}



}
