package com.realtyhub;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PropertyDAO {
	
	private DatabaseController dbController = DatabaseController.getInstance();
	
    public boolean addPropertyToDatabase(String loggedInUsername, String propertyType, String propertyAddress, String rentOrSale, int price) {

        String query = "INSERT INTO properties (propertyOwner, propertyType, propertyAddress, rentOrSale, price, verified) " +
                       "VALUES (?, ?, ?, ?, ?, 0)";

        try (PreparedStatement statement = dbController.prepareStatement(query)) {
            statement.setString(1, loggedInUsername);
            statement.setString(2, propertyType);
            statement.setString(3, propertyAddress);
            statement.setString(4, rentOrSale);
            statement.setInt(5, price);
            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public ObservableList<Property> loadPropertiesFromDatabase(String username) {
        ObservableList<Property> properties = FXCollections.observableArrayList();

        String query = "SELECT id, propertyOwner, propertyType, propertyAddress, rentOrSale, price, verified FROM properties WHERE propertyOwner = ?";

        try (PreparedStatement statement = dbController.prepareStatement(query)) {

            statement.setString(1, username); // Filter by the logged-in user
            ResultSet resultSet = statement.executeQuery();

            properties = PropertyFactory.createPropertiesFromResultSet(resultSet);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return properties;
    }
    
    public ObservableList<Property> loadPropertiesFromDatabase(String type, String transactionType, String minPrice, String maxPrice) {
        ObservableList<Property> properties = FXCollections.observableArrayList();

        try (PreparedStatement statement = SearchQueryFactory.createSearchQuery(dbController, type, transactionType, minPrice, maxPrice)) {

            ResultSet resultSet = statement.executeQuery();

            properties = PropertyFactory.createPropertiesFromResultSet(resultSet);

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return properties;
    }

    
    public void removePropertyFromDatabase(int propertyId) {
        String query = "DELETE FROM properties WHERE id = ?";

        try (PreparedStatement statement = dbController.prepareStatement(query)) {

            statement.setInt(1, propertyId);
            statement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public boolean updatePropertyInDatabase(int id, String propertyType, String address, String transactionType, String price) {
    	
        String query = "UPDATE properties SET propertyType = ?, propertyAddress = ?, rentOrSale = ?, price = ?, verified = ? WHERE id = ?";

        try (PreparedStatement statement = dbController.prepareStatement(query)) {

            statement.setString(1, propertyType);
            statement.setString(2, address);
            statement.setString(3, transactionType);
            statement.setInt(4, Integer.parseInt(price)); // Convert price to int
            statement.setBoolean(5, false); // Set verified to false
            statement.setInt(6, id);

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    
    public List<Property> fetchUnverifiedProperties() {
        List<Property> properties = new ArrayList<>();
        
        
            String query = "SELECT id, propertyOwner, propertyType, propertyAddress, rentOrSale, price, verified FROM properties WHERE verified = 0";
            
        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                // Create Property objects and add to the list
                Property property = new Property(
                        rs.getInt("id"), // Fetch the id
                        rs.getString("propertyOwner"),
                        rs.getString("propertyType"),
                        rs.getString("propertyAddress"),
                        rs.getString("rentOrSale"),
                        rs.getInt("price"),
                        rs.getString("verified").equals("1") ? "Verified" : "Not Verified" // Check the verified status
                );
                properties.add(property);
            }
        }
        catch (SQLException e) {
        	return null;
        }
        return properties;
    }
    
    public int approveProperties(List<Integer> selectedPropertyIds) {
        if (selectedPropertyIds.isEmpty()) {
            return -1;
        }

        // Update the properties to set verified = 1 (Verified)
        
            String updateQuery = "UPDATE properties SET verified = 1 WHERE id = ?";
            
            try (PreparedStatement stmt = dbController.prepareStatement(updateQuery)) {
                for (Integer propertyId : selectedPropertyIds) {
                    stmt.setInt(1, propertyId); // Use the property ID to update
                    stmt.executeUpdate();
                }

            return 0;
            
            }
        catch (SQLException e) {
        	return 1;
        }
            
    }
    
}