package com.realtyhub;

import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class PropertyFactory {

    public static ObservableList<Property> createPropertiesFromResultSet(ResultSet resultSet) throws SQLException {
        ObservableList<Property> properties = FXCollections.observableArrayList();

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String propertyOwner = resultSet.getString("propertyOwner");
            String propertyType = resultSet.getString("propertyType");
            String propertyAddress = resultSet.getString("propertyAddress");
            String rentOrSale = resultSet.getString("rentOrSale");
            int price = resultSet.getInt("price");
            boolean verified = resultSet.getBoolean("verified");

            properties.add(new Property(id, propertyOwner, propertyType, propertyAddress, rentOrSale, price, verified));
        }

        return properties;
    }
}