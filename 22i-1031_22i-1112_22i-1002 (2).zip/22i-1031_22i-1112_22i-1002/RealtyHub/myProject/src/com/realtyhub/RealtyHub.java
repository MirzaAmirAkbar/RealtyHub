package com.realtyhub;

import java.sql.*;

public class RealtyHub {
    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/RealtyHubDB";
    private static final String DATABASE_USER = "root"; // Replace with your MySQL username
    private static final String DATABASE_PASSWORD = "iamaazib63"; // Replace with your MySQL password

    public static void begin(String[] args) {
    	StartPage.myftn(args);
    }	
    
    public static void updateUserProfile(String username, String email, String address, String contactNumber, String type) {
        try (Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD)) {
            String query = "UPDATE users SET email = ?, address = ?, contact_number = ?, type = ? WHERE username = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, email);
                stmt.setString(2, address);
                stmt.setString(3, contactNumber);
                stmt.setString(4, type);
                stmt.setString(5, username);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Profile updated successfully for user: " + username);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error updating user profile: " + e.getMessage());
        }
    }
}
