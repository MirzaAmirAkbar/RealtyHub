package com.realtyhub;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.geometry.Insets;
import javafx.geometry.Pos;

public class RegisterPage {

    private Stage stage; // Reference to the primary stage

    public RegisterPage(Stage primaryStage) {
        this.stage = primaryStage;
    }

    public void showRegisterPage() {
        // Labels and fields for user details
        Label usernameLabel = new Label("Username:");
        usernameLabel.getStyleClass().add("label-title");
        TextField usernameField = new TextField();
        usernameField.setPromptText("Enter username");
        usernameField.getStyleClass().add("text-field");

        Label passwordLabel = new Label("Password:");
        passwordLabel.getStyleClass().add("label-title");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter password");
        passwordField.getStyleClass().add("password-field");

        Label emailLabel = new Label("Email:");
        emailLabel.getStyleClass().add("label-title");
        TextField emailField = new TextField();
        emailField.setPromptText("Enter email");
        emailField.getStyleClass().add("text-field");

        Label contactLabel = new Label("Contact:");
        contactLabel.getStyleClass().add("label-title");
        TextField contactField = new TextField();
        contactField.setPromptText("Enter contact number");
        contactField.getStyleClass().add("text-field");

        Label addressLabel = new Label("Address:");
        addressLabel.getStyleClass().add("label-title");
        TextArea addressArea = new TextArea();
        addressArea.setPromptText("Enter address");
        addressArea.setPrefRowCount(2);
        addressArea.getStyleClass().add("text-field");

        Label typeLabel = new Label("Type:");
        typeLabel.getStyleClass().add("label-title");
        ComboBox<String> typeComboBox = new ComboBox<>();
        typeComboBox.getItems().addAll("buyer", "seller");
        typeComboBox.setPromptText("Select type");
        typeComboBox.getStyleClass().add("combo-box");

        // Submit and Back buttons
        Button submitButton = new Button("Submit");
        submitButton.getStyleClass().add("button");
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button");

        // Button actions
        submitButton.setOnAction(event -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            String email = emailField.getText();
            String contact = contactField.getText();
            String address = addressArea.getText();
            String type = typeComboBox.getValue();

            UserDAO userDAO = new UserDAO();
            int validation = userDAO.registerUser(username, password, email, address, contact, type);

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setHeaderText(null);
            alert.setResizable(false);
            alert.setTitle("Registration Status");

            switch (validation) {
                case -1:
                    alert.setAlertType(Alert.AlertType.ERROR);
                    alert.setContentText("Error reading user data!");
                    break;
                case 0:
                    alert.setContentText("User Successfully Registered!");
                    alert.showAndWait();
                    goToStartPage();
                    return;
                case 1:
                    alert.setAlertType(Alert.AlertType.ERROR);
                    alert.setContentText("Error! Username already taken!");
                    break;
            }
            alert.show();
        });

        backButton.setOnAction(event -> goToStartPage());

        // HBox for side-by-side fields
        HBox usernameBox = createFieldRow(usernameLabel, usernameField);
        HBox passwordBox = createFieldRow(passwordLabel, passwordField);
        HBox emailBox = createFieldRow(emailLabel, emailField);
        HBox contactBox = createFieldRow(contactLabel, contactField);
        HBox typeBox = createFieldRow(typeLabel, typeComboBox);

        // Buttons row
        HBox buttonBox = new HBox(15, submitButton, backButton);
        buttonBox.setAlignment(Pos.CENTER);

        // VBox for all rows
        VBox vbox = new VBox(15);
        vbox.setAlignment(Pos.CENTER);
        vbox.setPadding(new Insets(20));
        vbox.getStyleClass().add("vbox");
        vbox.getChildren().addAll(usernameBox, passwordBox, emailBox, contactBox, addressLabel, addressArea, typeBox, buttonBox);

        // Center everything in the scene
        StackPane centerPane = new StackPane(vbox);

        // Set scene and stylesheet
        Scene registerScene = new Scene(centerPane, 600, 600); // Same size as other pages
        registerScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        stage.setScene(registerScene);
        stage.setTitle("Register Page");
        stage.show();
    }

    private HBox createFieldRow(Label label, Control field) {
        HBox hbox = new HBox(10, label, field); // Horizontal gap of 10
        hbox.setAlignment(Pos.CENTER_LEFT);
        hbox.setSpacing(10);
        return hbox;
    }

    private void goToStartPage() {
        StartPage startPage = new StartPage();
        startPage.start(stage);
    }
}
