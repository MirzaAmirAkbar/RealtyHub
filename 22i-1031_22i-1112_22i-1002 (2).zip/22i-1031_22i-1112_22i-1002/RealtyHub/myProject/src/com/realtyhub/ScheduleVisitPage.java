package com.realtyhub;

import java.time.LocalDate;

import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ScheduleVisitPage {
    
    private Stage stage; // Reference to the primary stage
    private String loggedInUsername;
    private String propertyOwner;
    private int property;

    // Constructor accepts Stage to allow switching scenes
    public ScheduleVisitPage(Stage primaryStage, String loggedInUsername, String propertyOwner, int property) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
        this.propertyOwner = propertyOwner;
        this.property = property;
    }

    public void showScheduleVisitPage() {
        // Create a label for the heading
        Label headingLabel = new Label("Schedule Visit Page");
        headingLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #007acc;");

        // Add padding and alignment for the heading
        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);
        headingPane.setStyle("-fx-background-color: #87CEEB; -fx-border-radius: 10px; -fx-border-color: #007acc; -fx-border-width: 2px;");

        // Date Picker for selecting the visit date
        DatePicker datePicker = new DatePicker();

        // Set a default date
        datePicker.setValue(LocalDate.now());

        // Listen for date change
        datePicker.setOnAction(event -> {
            LocalDate selectedDate = datePicker.getValue();
            System.out.println("Selected date: " + selectedDate);
        });

        // Propose Date Button
        Button proposeDateButton = new Button("Propose Date");
        proposeDateButton.setStyle("-fx-background-color: #007acc; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");

        proposeDateButton.setOnAction(event -> {
            // Get values from the input fields
            LocalDate selectedDate = datePicker.getValue();
            
            VisitDAO visitDAO = new VisitDAO();
            int validation = visitDAO.addVisit(loggedInUsername, propertyOwner, property, selectedDate);

            if (validation == 0) {
	            Alert successDialog = new Alert(Alert.AlertType.INFORMATION);
	            successDialog.setTitle("Visit Date Proposed");
	            successDialog.setHeaderText(null);
	            successDialog.setContentText("Visit Date Proposed!");
	            successDialog.showAndWait();
            }
            else {
            	Alert failureDialog = new Alert(Alert.AlertType.INFORMATION);
	            failureDialog.setTitle("Error");
	            failureDialog.setHeaderText(null);
	            failureDialog.setContentText("Error! Visit Date Could Not Be Proposed.");
	            failureDialog.showAndWait();
            }

            HomePage homePage = new HomePage(stage, loggedInUsername);
            homePage.showHomePage();
        });

        // Back Button
        Button backButton = new Button("Back");
        backButton.setStyle("-fx-background-color: #FF6347; -fx-text-fill: white; -fx-padding: 10px; -fx-font-size: 14px; -fx-border-radius: 5px;");
        backButton.setOnAction(event -> {
            // Create and show the View Properties Page
            ViewPropertiesPage viewPropertiesPage = new ViewPropertiesPage(stage, loggedInUsername); 
            viewPropertiesPage.showViewPropertiesPage();
        });

        // Layout
        VBox centerBox = new VBox(20);
        centerBox.setPadding(new Insets(20));
        centerBox.getChildren().addAll(datePicker, proposeDateButton, backButton);

        // Root layout
        BorderPane root = new BorderPane();
        root.setTop(headingPane);
        root.setCenter(centerBox);
        root.setStyle("-fx-background-color: #87CEEB; -fx-border-radius: 10px; -fx-border-color: #007acc; -fx-border-width: 2px;");

        // Scene for the Schedule Visit Page
        Scene homeScene = new Scene(root, 600, 400);

        // Set the scene and show the stage
        stage.setScene(homeScene);
        stage.setTitle("Schedule Visit");
        stage.show();
    }

}
