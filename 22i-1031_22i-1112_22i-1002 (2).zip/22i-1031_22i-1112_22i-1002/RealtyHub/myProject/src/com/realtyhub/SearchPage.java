package com.realtyhub;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class SearchPage {

    private Stage stage; // Reference to the primary stage
    private String loggedInUsername;

    // Constructor accepts Stage to allow switching scenes
    public SearchPage(Stage primaryStage, String loggedInUsername) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
    }

    public void showSearchPage() {
        // Create input fields for user details
        TextField typeField = new TextField();
        typeField.setPromptText("Enter Property Type");
        typeField.getStyleClass().add("text-field");

        // ComboBox for selecting the transaction type (e.g., For Rent, For Sale)
        ComboBox<String> transactionTypeComboBox = new ComboBox<>();
        transactionTypeComboBox.getItems().addAll("For Rent", "For Sale");
        transactionTypeComboBox.setPromptText("Select Type");
        transactionTypeComboBox.getStyleClass().add("combo-box");

        TextField minPriceField = new TextField();
        minPriceField.setPromptText("Enter Min Price");
        minPriceField.getStyleClass().add("text-field");

        TextField maxPriceField = new TextField();
        maxPriceField.setPromptText("Enter Max Price");
        maxPriceField.getStyleClass().add("text-field");

        // Create a Search button
        Button searchButton = createButton("Search");

        // Label to display feedback
        Label feedbackLabel = new Label();
        feedbackLabel.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

        // Handle the Search button action
        searchButton.setOnAction(event -> {
            // Get values from the input fields
            String type = typeField.getText();
            String transactionType = transactionTypeComboBox.getValue();
            String minPrice = minPriceField.getText();
            String maxPrice = maxPriceField.getText();

            // Pass the filters to the ViewPropertiesPage
            ViewPropertiesPage viewPropertiesPage = new ViewPropertiesPage(stage, loggedInUsername, type, transactionType, minPrice, maxPrice);
            viewPropertiesPage.showViewPropertiesPage(); // Show the filtered properties
        });

        // Create a Back button to return to the ViewPropertiesPage
        Button backButton = createButton("Back");
        backButton.setOnAction(event -> {
            // Returning to the ViewPropertiesPage
            ViewPropertiesPage viewPropertiesPage = new ViewPropertiesPage(stage, loggedInUsername, null, null, null, null); // Pass null to load all properties
            viewPropertiesPage.showViewPropertiesPage(); // Show all properties page
        });

        // Create a VBox to arrange the input fields vertically
        VBox vbox = new VBox(10); // Adjusted gap between elements
        vbox.setPadding(new Insets(20, 20, 20, 20)); // Add padding to the VBox container
        vbox.getStyleClass().add("vbox");
        vbox.setAlignment(Pos.CENTER);  // Center all elements horizontally in the VBox

        // Create an HBox to center the buttons horizontally and allow side-by-side placement
        HBox buttonBox = new HBox(10); // Reduced gap between buttons to 10px
        buttonBox.setAlignment(Pos.CENTER); // Center the buttons in HBox
        buttonBox.getChildren().addAll(searchButton, backButton); // Add buttons to the HBox

        vbox.getChildren().addAll(typeField, transactionTypeComboBox, minPriceField, maxPriceField, feedbackLabel, buttonBox);

        // Create a Scene for the Search Page
        Scene searchScene = new Scene(vbox, 500, 500);
        searchScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Set the new Scene for the Stage
        stage.setScene(searchScene);
        stage.setTitle("Search Properties");
        stage.show();
    }

    // Method to create buttons with a common style
    private Button createButton(String text) {
        Button button = new Button(text);
        button.getStyleClass().add("button");
        button.setPrefWidth(120); // Ensure all buttons have equal width
        return button;
    }
}
