package com.realtyhub;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SearchQueryFactory {
    public static PreparedStatement createSearchQuery(DatabaseController dbController, 
                                                      String type, String transactionType, 
                                                      String minPrice, String maxPrice) throws SQLException {
    	
        StringBuilder queryBuilder = new StringBuilder(
            "SELECT * FROM properties WHERE verified = 1 AND id NOT IN (SELECT property_id FROM transactions)");

        // Build dynamic conditions
        if (type != null && !type.isEmpty()) queryBuilder.append(" AND propertyType = ?");
        if (transactionType != null && !transactionType.isEmpty()) queryBuilder.append(" AND rentOrSale = ?");
        if (minPrice != null && !minPrice.isEmpty()) queryBuilder.append(" AND price >= ?");
        if (maxPrice != null && !maxPrice.isEmpty()) queryBuilder.append(" AND price <= ?");

        PreparedStatement statement = dbController.prepareStatement(queryBuilder.toString());

        // Bind parameters dynamically
        int parameterIndex = 1;
        if (type != null && !type.isEmpty()) statement.setString(parameterIndex++, type);
        if (transactionType != null && !transactionType.isEmpty()) statement.setString(parameterIndex++, transactionType);
        if (minPrice != null && !minPrice.isEmpty()) statement.setInt(parameterIndex++, Integer.parseInt(minPrice));
        if (maxPrice != null && !maxPrice.isEmpty()) statement.setInt(parameterIndex++, Integer.parseInt(maxPrice));

        return statement;
    }
}