package com.realtyhub;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class StartPage extends Application {

    private String selectedOption = ""; // Variable to store selected option

    @Override
    public void start(Stage primaryStage) {
        // Create buttons for Login, Register, and Exit
        Button loginButton = new Button("Login");
        Button registerButton = new Button("Register");
        Button exitButton = new Button("Exit");

        // Apply CSS class to buttons
        loginButton.getStyleClass().add("button");
        registerButton.getStyleClass().add("button");
        exitButton.getStyleClass().add("button");

        // Set up event handlers
        loginButton.setOnAction(event -> {
            selectedOption = "Login"; // Save selected option
            System.out.println("Selected Option: " + selectedOption);
            // Navigate to the Login Page
            LoginPage loginPage = new LoginPage(primaryStage); // Create LoginPage and pass primaryStage
            loginPage.showLoginPage(); // Call the method to switch to Login Page
        });

        registerButton.setOnAction(event -> {
            selectedOption = "Register"; // Save selected option
            System.out.println("Selected Option: " + selectedOption);
            // Switch to Register Page
            RegisterPage registerPage = new RegisterPage(primaryStage); // Create RegisterPage and pass primaryStage
            registerPage.showRegisterPage(); // Call the method to switch to Register Page
        });

        exitButton.setOnAction(event -> {
            selectedOption = "Exit"; // Save selected option
            System.out.println("Selected Option: " + selectedOption);
            primaryStage.close(); // Close the start page
            System.exit(0); // Exit the application
        });

        // Layout container (VBox) to arrange buttons vertically
        VBox vbox = new VBox(20); // 20px spacing between buttons
        vbox.getChildren().addAll(loginButton, registerButton, exitButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.getStyleClass().add("vbox"); // Apply VBox CSS class

        // Create a title label
        Label titleLabel = new Label("Welcome to RealtyHub");
        titleLabel.getStyleClass().add("label-title"); // Apply label CSS class

        // Add title label to VBox
        vbox.getChildren().add(0, titleLabel); // Add at the top of VBox

        // Create a Scene and set it on the Stage
        Scene scene = new Scene(vbox, 400, 400);

        // Add the CSS file to the scene
        scene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Set the Stage title
        primaryStage.setTitle("RealtyHub");

        // Set the Scene to the Stage and display
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void myftn(String[] args) {
        launch(args); // Use the JavaFX launch method to start the application
    }
}
