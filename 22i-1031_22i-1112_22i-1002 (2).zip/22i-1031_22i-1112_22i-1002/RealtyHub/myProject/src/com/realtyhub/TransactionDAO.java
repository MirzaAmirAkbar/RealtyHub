package com.realtyhub;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class TransactionDAO {
	private DatabaseController dbController = DatabaseController.getInstance();
	
    public void saveTransaction(String username, Property selectedProperty) throws SQLException {        
        String query = "INSERT INTO Transactions (buyer, seller, property_id, transaction_date) VALUES (?, ?, ?, ?)";


        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, selectedProperty.getPropertyOwner()); // Seller's username
            stmt.setInt(3, selectedProperty.getId()); // Property ID
            stmt.setTimestamp(4, java.sql.Timestamp.valueOf(LocalDateTime.now())); // Transaction date
            stmt.executeUpdate();
        }
     
    }
	
}