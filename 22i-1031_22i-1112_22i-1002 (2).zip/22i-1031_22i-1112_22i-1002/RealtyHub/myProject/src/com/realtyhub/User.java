package com.realtyhub;

import java.io.Serializable;

public class User implements Serializable {
    private String username;
    private String password;
    private String email;
    private String address;
    private String contactNumber;
    private String type; // "buyer" or "seller"

    public User(String username, String password, String email, String address, String contactNumber, String type) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.address = address;
        this.contactNumber = contactNumber;
        this.type = type;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String toString() {
        return username + "," + password + "," + email + "," + address + "," + contactNumber + "," + type;
    }

    public static User fromString(String userData) {
        String[] parts = userData.split(",");
        return new User(parts[0], parts[1], parts[2], parts[3], parts[4], parts[5]);
    }
}