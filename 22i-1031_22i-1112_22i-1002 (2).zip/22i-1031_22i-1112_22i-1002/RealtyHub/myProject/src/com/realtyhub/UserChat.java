package com.realtyhub;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.IntegerProperty;

public class UserChat {
    private StringProperty userName;
    private IntegerProperty propertyID;

    // Constructor
    public UserChat(String userName, int propertyID) {
        this.userName = new SimpleStringProperty(userName);
        this.propertyID = new SimpleIntegerProperty(propertyID);
    }

    // Getter for userName
    public String getUserName() {
        return userName.get();
    }

    public StringProperty getUserNameProperty() {
        return userName;
    }

    // Getter for propertyID
    public int getPropertyID() {
        return propertyID.get();
    }

    public IntegerProperty getPropertyIDProperty() {
        return propertyID;
    }
}