package com.realtyhub;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDAO {
    private DatabaseController dbController = DatabaseController.getInstance();
    
    private boolean isUsernameExists(String username) {
    	String query = "SELECT * FROM users WHERE username = ?"; 
        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
            stmt.setString(1, username);
            ResultSet resultSet = stmt.executeQuery();
            return resultSet.next(); // If a record is found, return true
        }
         catch (SQLException e) {
            System.err.println("Error checking username: " + e.getMessage());
        }
        
        return false;
    }

    public int registerUser(String username, String password, String email, String address, String contactNumber, String type) {
    	if (isUsernameExists(username)) {
            return 1; // Username already taken
        }
    	
        String query = "INSERT INTO users (username, password, email, address, contact_number, type) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
        	stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.setString(3, email);
            stmt.setString(4, address);
            stmt.setString(5, contactNumber);
            stmt.setString(6, type);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                return 0; // Success
            }
        } catch (SQLException e) {
            System.err.println("Error saving user data: " + e.getMessage());
        }
        
        return -1;
    }
    
    public int login(String username, String password) {
    	if (!isUsernameExists(username)) {
            return 1; // Username already taken
        }
    	
        String query = "SELECT * FROM users WHERE username = ? AND password = ?";
        try (PreparedStatement stmt = dbController.prepareStatement(query)) {
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet resultSet = stmt.executeQuery();
            if (resultSet.next()) {
                return 0; // Success
            } else {
                return 2; // incorrect password
            }
        }
         catch (SQLException e) {
            System.err.println("Error reading user data: " + e.getMessage());
            return -1; // Error
        }
    }
    
    public int updateUserDetails(String email, String address, String contact, String username) {
        String updateQuery = "UPDATE users SET email = ?, address = ?, contact_number = ? WHERE username = ?";
        try (PreparedStatement stmt = dbController.prepareStatement(updateQuery)) {
            stmt.setString(1, email);
            stmt.setString(2, address);
            stmt.setString(3, contact);
            stmt.setString(4, username);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                return 0;
            }
        }
         catch (SQLException e) {
            
        }
        
        return 1;
    }

    public String[] fetchUserDetails(String username) {
            String query = "SELECT email, address, contact_number FROM users WHERE username = ?";
            try (PreparedStatement stmt = dbController.prepareStatement(query)) {
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                	String[] userDetails = new String[3];
                	
                	userDetails[0] = rs.getString("email");
                	userDetails[1] = rs.getString("address");
                	userDetails[2] = rs.getString("contact_number");
                	
                	return userDetails;
                }
            }
         catch (SQLException e) {

        }
            
            return null;
    }
    
    
    public String getUserType(String username) {
        String query = "select type from users where username = ?";
        try (PreparedStatement statement = dbController.prepareStatement(query)) {
        	statement.setString(1, username);
         	ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
            	return resultSet.getString("type");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}