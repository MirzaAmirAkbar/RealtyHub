package com.realtyhub;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ViewPropertiesPage {
    private Stage stage;
    private String loggedInUsername;
    ObservableList<Property> propertyList;
    private int propertyId;
    private String propertyOwner;

    public ViewPropertiesPage(Stage primaryStage, String loggedInUsername) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
        PropertyDAO propertyDAO = new PropertyDAO();
        propertyList = propertyDAO.loadPropertiesFromDatabase(null, null, null, null);
    }

    public ViewPropertiesPage(Stage primaryStage, String type, String transactionType, String minPrice, String maxPrice) {
        this.stage = primaryStage;
        PropertyDAO propertyDAO = new PropertyDAO();
        propertyList = propertyDAO.loadPropertiesFromDatabase(type, transactionType, minPrice, maxPrice);
    }

    public ViewPropertiesPage(Stage primaryStage, String loggedInUsername, String type, String transactionType, String minPrice, String maxPrice) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;
        PropertyDAO propertyDAO = new PropertyDAO();
        propertyList = propertyDAO.loadPropertiesFromDatabase(type, transactionType, minPrice, maxPrice);
    }

    public void showViewPropertiesPage() {
        // Create a label for the heading
        Label headingLabel = new Label("View Properties Page");
        headingLabel.getStyleClass().add("label-title");

        // Add padding and alignment for the heading
        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);

        // TableView to display properties
        TableView<Property> propertiesTable = new TableView<>();
        propertiesTable.setPrefHeight(300);
        propertiesTable.getStyleClass().add("table-view"); // Apply table style

        // Define columns
        TableColumn<Property, Integer> idColumn = new TableColumn<>("Property ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Property, String> ownerColumn = new TableColumn<>("Property Owner");
        ownerColumn.setCellValueFactory(new PropertyValueFactory<>("propertyOwner"));

        TableColumn<Property, String> typeColumn = new TableColumn<>("Property Type");
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("propertyType"));

        TableColumn<Property, String> addressColumn = new TableColumn<>("Address");
        addressColumn.setCellValueFactory(new PropertyValueFactory<>("propertyAddress"));

        TableColumn<Property, String> transactionColumn = new TableColumn<>("Transaction Type");
        transactionColumn.setCellValueFactory(new PropertyValueFactory<>("rentOrSale"));

        TableColumn<Property, Integer> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        TableColumn<Property, String> verifiedColumn = new TableColumn<>("Verified");
        verifiedColumn.setCellValueFactory(new PropertyValueFactory<>("verifiedStatus"));

        // Add columns to the table
        propertiesTable.getColumns().addAll(idColumn, ownerColumn, typeColumn, addressColumn, transactionColumn, priceColumn, verifiedColumn);

        // Add a listener to the selection model
        propertiesTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                propertyId = newSelection.getId();
                propertyOwner = newSelection.getPropertyOwner();
            }
        });

        // Load properties from the database
        propertiesTable.setItems(propertyList);

        // Buttons at the bottom
        Button backButton = createButton("Back");
        backButton.setOnAction(event -> {
            HomePage homePage = new HomePage(stage, loggedInUsername);
            homePage.showHomePage();
        });

        Button searchButton = createButton("Search");
        searchButton.setOnAction(event -> {
            SearchPage searchPage = new SearchPage(stage, loggedInUsername);
            searchPage.showSearchPage();
        });

        Button contactPropertyOwnerButton = createButton("Contact Property Owner");
        contactPropertyOwnerButton.setOnAction(event -> {
            ChatPage chatPage = new ChatPage(stage);
            chatPage.showChatPage(loggedInUsername, propertyOwner, propertyId);
        });

        Button scheduleVisitButton = createButton("Schedule Visit");
        scheduleVisitButton.setOnAction(event -> {
            Property selectedProperty = propertiesTable.getSelectionModel().getSelectedItem();
            if (selectedProperty != null) {
                ScheduleVisitPage scheduleVisitPage = new ScheduleVisitPage(stage, loggedInUsername, propertyOwner, propertyId);
                scheduleVisitPage.showScheduleVisitPage();
            } else {
                showAlert("No Property Selected", "Please select a property to schedule a visit.");
            }
        });

        Button buyRentButton = createButton("Buy/Rent");
        buyRentButton.setOnAction(event -> {
            Property selectedProperty = propertiesTable.getSelectionModel().getSelectedItem();
            if (selectedProperty != null) {
                PaymentPage paymentPage = new PaymentPage(stage, loggedInUsername, selectedProperty);
                paymentPage.showPaymentPage();
            } else {
                showAlert("No Property Selected", "Please select a property to proceed with buying/renting.");
            }
        });

        // Button container
        HBox buttonBox = new HBox(20);
        buttonBox.setPadding(new Insets(20, 0, 0, 0));
        buttonBox.getChildren().addAll(backButton, searchButton, contactPropertyOwnerButton, scheduleVisitButton, buyRentButton);

        // Main container
        VBox centerBox = new VBox(20);
        centerBox.setPadding(new Insets(20));
        centerBox.getChildren().addAll(propertiesTable, buttonBox);

        // Create a root layout
        BorderPane root = new BorderPane();
        root.setTop(headingPane);
        root.setCenter(centerBox);
        root.getStyleClass().add("vbox"); // Apply vbox style

        // Create a Scene for the Home Page
        Scene homeScene = new Scene(root, 800, 600); // Adjusted size to fit the layout better
        homeScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());

        // Set the Scene for the Stage
        stage.setScene(homeScene);
        stage.setTitle("View Properties Page");
        stage.show();
    }


    private Button createButton(String text) {
        Button button = new Button(text);
        button.getStyleClass().add("button");
        button.setPrefWidth(120); // Ensure all buttons have equal width
        return button;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
