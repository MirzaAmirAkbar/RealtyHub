package com.realtyhub;

import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ViewVisitsPage {
    private Stage stage; // Reference to the primary stage
    private String loggedInUsername;
    private String userType;
    private String buyer;
    private String seller;
    int visitID;

    private ObservableList<Visit> visitList;

    public ViewVisitsPage(Stage primaryStage, String loggedInUsername) {
        this.stage = primaryStage;
        this.loggedInUsername = loggedInUsername;

        UserDAO userDAO = new UserDAO();
        userType = userDAO.getUserType(loggedInUsername);
    }

    public void showViewVisitsPage() {
        // Page Heading
        Label headingLabel = new Label("View Visits Page");
        headingLabel.getStyleClass().add("label-title");

        // Add padding and alignment for the heading
        StackPane headingPane = new StackPane();
        headingPane.setPadding(new Insets(20, 0, 20, 0));
        headingPane.getChildren().add(headingLabel);
        headingPane.getStyleClass().add("vbox");

        // Visits Table
        TableView<Visit> visitsTable = new TableView<>();
        visitsTable.setPrefHeight(300);

        // Define columns
        TableColumn<Visit, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<Visit, String> buyerColumn = new TableColumn<>("Buyer");
        buyerColumn.setCellValueFactory(new PropertyValueFactory<>("Buyer"));

        TableColumn<Visit, String> sellerColumn = new TableColumn<>("Seller");
        sellerColumn.setCellValueFactory(new PropertyValueFactory<>("Seller"));

        TableColumn<Visit, String> propertyColumn = new TableColumn<>("PropertyID");
        propertyColumn.setCellValueFactory(new PropertyValueFactory<>("PropertyID"));

        TableColumn<Visit, String> dateColumn = new TableColumn<>("Date");
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("Date"));

        TableColumn<Visit, String> statusColumn = new TableColumn<>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("Status"));

        visitsTable.getColumns().addAll(buyerColumn, sellerColumn, propertyColumn, dateColumn, statusColumn, idColumn);

        // Load Visit Data
        VisitDAO visitDAO = new VisitDAO();
        visitList = visitDAO.getVisitList(loggedInUsername, userType);
        visitsTable.setItems(visitList);

        // Selection Listener for Sellers
        if (userType.equalsIgnoreCase("seller")) {
            visitsTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
                if (newSelection != null) {
                    this.buyer = newSelection.getBuyer();
                    this.seller = newSelection.getSeller();
                    this.visitID = newSelection.getId();
                }
            });
        }

        // Buttons
        Button backButton = new Button("Back");
        backButton.getStyleClass().add("button");
        backButton.setOnAction(event -> {
            HomePage homePage = new HomePage(stage, loggedInUsername);
            homePage.showHomePage();
        });

        Button acceptButton = new Button("Accept");
        acceptButton.getStyleClass().add("button");
        acceptButton.setOnAction(event -> {
            visitDAO.changeVisitStatus(visitID, "accepted");

            showAlert(Alert.AlertType.INFORMATION, "Visit Accepted", "The visit has been successfully accepted!");
            visitList = visitDAO.getVisitList(loggedInUsername, userType);
            visitsTable.setItems(visitList);
        });

        Button rejectButton = new Button("Reject");
        rejectButton.getStyleClass().add("button");
        rejectButton.setOnAction(event -> {
            visitDAO.changeVisitStatus(visitID, "rejected");

            showAlert(Alert.AlertType.INFORMATION, "Visit Rejected", "The visit has been successfully rejected!");
            visitList = visitDAO.getVisitList(loggedInUsername, userType);
            visitsTable.setItems(visitList);
        });

        // Button Container (Aligned in One Line)
        HBox buttonContainer = new HBox(10, backButton);
        
        // Add buttons for sellers only
        if (userType.equalsIgnoreCase("seller")) {
            buttonContainer.getChildren().addAll(acceptButton, rejectButton);
        }

        buttonContainer.setPadding(new Insets(10, 0, 0, 0));
        buttonContainer.setStyle("-fx-alignment: center;");

        // Center Content
        VBox centerBox = new VBox(20, visitsTable, buttonContainer);
        centerBox.setPadding(new Insets(20));
        centerBox.getStyleClass().add("vbox");

        // Root Layout
        BorderPane root = new BorderPane();
        root.setTop(headingPane);
        root.setCenter(centerBox);

        // Scene
        Scene viewVisitsScene = new Scene(root, 800, 600);
        viewVisitsScene.getStylesheets().add(getClass().getResource("style.css").toExternalForm());
        stage.setScene(viewVisitsScene);
        stage.setTitle("View Visits");
        stage.show();
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
