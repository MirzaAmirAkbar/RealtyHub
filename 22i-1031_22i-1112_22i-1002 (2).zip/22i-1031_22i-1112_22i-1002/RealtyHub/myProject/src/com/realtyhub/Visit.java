package com.realtyhub;

public class Visit {
	private int id;
	private String buyer;
	private String seller;
	private int propertyID;
	private String date;
	private String status;
	
	public Visit(int id, String buyer, String seller, int propertyID, String date, String status) { 
		this.id=id;
		this.buyer = buyer;
		this.seller=seller;
		this.propertyID = propertyID;
		this.date=date;
		this.status=status;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPropertyID() {
		return propertyID;
	}

	public String getBuyer() {
		return buyer;
	}

	public String getSeller() {
		return seller;
	}

	public String getDate() {
		return date;
	}

	public String getStatus() {
		return status;
	}
}