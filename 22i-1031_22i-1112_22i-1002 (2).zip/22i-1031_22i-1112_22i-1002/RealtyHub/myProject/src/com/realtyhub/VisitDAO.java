package com.realtyhub;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class VisitDAO {
	
	private DatabaseController dbController = DatabaseController.getInstance();
	
	public int addVisit(String username, String owner, int propertyID, LocalDate selectedDate) {
        String query = "INSERT INTO visits (buyer, seller, propertyID, visitDate, status) VALUES (?, ?, ?, ?, 'Proposed');";
        try (PreparedStatement statement = dbController.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, owner);
            statement.setString(3, String.valueOf(propertyID));
            statement.setString(4, selectedDate.toString());
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
            	return 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return 1;
    }
	
    public ObservableList<Visit> getVisitList(String username, String userType) {
    	ObservableList<Visit> visits = FXCollections.observableArrayList();

        String query = "";
        
        if (userType.equalsIgnoreCase("buyer")) {
        	query = "SELECT id, buyer, seller, propertyID, visitDate, status FROM visits where buyer = ? ";
        }
        else {
        	query = "SELECT id, buyer, seller, propertyID, visitDate, status FROM visits where seller = ? ";
        }

        try (PreparedStatement statement = dbController.prepareStatement(query)) {
        	
        	statement.setString(1, username);

            //statement.setString(1, loggedInUsername); // Filter by the logged-in user
            ResultSet resultSet = statement.executeQuery();

            visits = VisitFactory.createVisitsFromResultSet(resultSet);
            
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return visits;
    }
    
    public void changeVisitStatus(int id, String newStatus) {
        String query = "update visits set status = ? where id = ?";

        try (PreparedStatement statement = dbController.prepareStatement(query)) {
        	statement.setString(1, newStatus);
        	statement.setString(2,  String.valueOf(id));
        	
        	System.out.println(String.valueOf(id) + " " + newStatus);

            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
	
}