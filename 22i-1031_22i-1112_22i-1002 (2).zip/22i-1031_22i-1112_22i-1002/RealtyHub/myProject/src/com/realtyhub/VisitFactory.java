package com.realtyhub;

import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class VisitFactory {

    public static ObservableList<Visit> createVisitsFromResultSet(ResultSet resultSet) throws SQLException {
        ObservableList<Visit> visits = FXCollections.observableArrayList();

        while (resultSet.next()) {
            int id = resultSet.getInt("id");
            String buyer = resultSet.getString("buyer");
            String seller = resultSet.getString("seller");
            int propertyID = resultSet.getInt("propertyID");
            String visitDate = resultSet.getString("visitDate");
            String status = resultSet.getString("Status");

            visits.add(new Visit(id, buyer, seller, propertyID, visitDate, status));
        }

        return visits;
    }
}