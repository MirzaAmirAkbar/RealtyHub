/**
 * 
 */
/**
 * 
 */
module RealtyHub {
	exports com.realtyhub;
	requires java.sql;
	requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires java.mail;
}